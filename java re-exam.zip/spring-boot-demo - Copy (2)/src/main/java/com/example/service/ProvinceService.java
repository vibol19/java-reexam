package com.example.service;

import com.example.entity.Province;

public interface ProvinceService {
    Province add(Province provinceName);

    Province update(Province provinceName);

    boolean deleteById(Long provinceId);

    Province findById(Long provinceId);

}
