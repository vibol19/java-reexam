package com.example.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.entity.Province;
import com.example.repository.ProvinceRepository;
import com.example.service.ProvinceService;

@Service
public class ProvinceServiceImpl implements ProvinceService{
    private ProvinceRepository provinceRepository;

    @Autowired
    public ProvinceServiceImpl(ProvinceServiceImpl provinceRepository){
        this.provinceRepository = provinceRepository;
    }
    @Override
    public Province add(Province provinceName){
        return provinceRepository.save(provinceName);

    }
    @Override
    public Province update(Province provinceName){
        Province provinceToUpdate = this.provinceRepository.findById(provinceName.getProvinceId().orElse(null));
        if (provinceToUpdate == null){
            System.out.println("Province Not Found");
            return null;
        }
        provinceToUpdate.setProvinceName(provinceName.getProvinceName());
        provinceToUpdate.setProvinceNameInKhmer(provinceName.getProvinceNameInKhmer());
        return this.provinceRepository.save(provinceToUpdate);
    }
    @Override
    public boolean deleteById(long provinceId){
        Province province = this.provinceRepository.findById(provinceId).orElse(null);
        if (province == null){
            return false;
        }
        provinceRepository.deleteById(provinceId);
        return true;
    }
    @Override
    public Province findById(Long provinceId){
        return provinceRepository.findById(provinceId).orElse(null);
    }
}
