package com.example.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
@Table(name = "tp_district")

public class District {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column
    private Integer dId;

    private Integer numOfKrong;
    private Integer numOfSrok;
    private Integer numOfKhan;

    @OneToMany(mappedBy = "district")
    private List<Province> provinces;
}









