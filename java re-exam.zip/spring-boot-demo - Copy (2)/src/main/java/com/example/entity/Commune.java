package com.example.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
@Table(name = "tp_commune")

public class Commune{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer numOfCommune;
    private Integer cId;
    private Integer numOfSongkat;

    @OneToMany(mappedBy = "commune")
    private List<District> products;



}

