package com.example.entity;

import java.util.*;

import com.example.entity.mappleclass.BaseEntity;
import jakarta.persistence.*;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Scanner;

@Entity
@Transactional
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
@Data
@Table(name = "tp_province")
public class Province extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)

    private Long provinceId;
    @Column(name = "provinceName", length = 100, nullable = false, unique = true)
    private String provinceName;
    @Column(name = "provinceNameInKhmer", length = 100, nullable = false, unique = true)
    private String provinceNameInKhmer;


    @OneToOne(mappedBy = "province")
    private Province province;


}


